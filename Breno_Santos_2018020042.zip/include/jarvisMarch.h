#ifndef JARVISMARCH_H
#define JARVISMARCH_H
#include "../include/manager.h"

int orientation(Point p, Point q, Point r);
void jarvisMarch(Point points[], int n);

#endif
